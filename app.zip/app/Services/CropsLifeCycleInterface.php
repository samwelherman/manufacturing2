<?php

namespace App\Services;

Interface CropsLifeCycleInterface
{
    public function landPreparation($data,$type,$function); 

  
}